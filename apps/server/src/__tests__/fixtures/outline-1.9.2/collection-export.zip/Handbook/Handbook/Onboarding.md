# Onboarding

The first day.