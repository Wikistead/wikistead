# Onboarding

Onboarding body.

![](files/01a024c7-a4b2-73b8-9348-897a9d546080/メモ_図.png)